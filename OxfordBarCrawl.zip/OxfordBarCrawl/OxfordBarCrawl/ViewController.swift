//
//  ViewController.swift
//  OxfordBarCrawl
//
//  Created by Danielle Sika on 2/27/19.
//  Copyright © 2019 Danielle Sika. All rights reserved.
//  Modified Code from <script src="https://gist.github.com/leoiphonedev/be0787041e6c44d4b1e66fbd49f827b5.js"></script>
//  Also referenced https://stackoverflow.com/questions/38041688/how-to-change-button-image-in-swift/42202708
//  And https://www.iostutorialjunction.com/2018/01/create-checkbox-in-swift-ios-sdk-tutorial-for-beginners.html?m=1

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var bar1868check: UIButton!
    @IBOutlet weak var circlecheck: UIButton!
    @IBOutlet weak var LFTcheck: UIButton!
    @IBOutlet weak var MIAcheck: UIButton!
    @IBOutlet weak var sidecheck: UIButton!
    @IBOutlet weak var steincheck: UIButton!
    @IBOutlet weak var chankcheck: UIButton!
    @IBOutlet weak var brickcheck: UIButton!
    @IBOutlet weak var cornercheck: UIButton!
    @IBOutlet weak var maccheck: UIButton!
    @IBOutlet weak var opubcheck: UIButton!
    @IBOutlet weak var skippcheck: UIButton!
    @IBOutlet weak var newcheck: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let bardone = UIImage(named: "Checkmark")
        bar1868check.setImage(bardone, for: UIControl.State.selected)
        circlecheck.setImage(bardone, for: UIControl.State.selected)
        LFTcheck.setImage(bardone, for: UIControl.State.selected)
        MIAcheck.setImage(bardone, for: UIControl.State.selected)
        sidecheck.setImage(bardone, for: UIControl.State.selected)
        steincheck.setImage(bardone, for: UIControl.State.selected)
        chankcheck.setImage(bardone, for: UIControl.State.selected)
        brickcheck.setImage(bardone, for: UIControl.State.selected)
        cornercheck.setImage(bardone, for: UIControl.State.selected)
        maccheck.setImage(bardone, for: UIControl.State.selected)
        opubcheck.setImage(bardone, for: UIControl.State.selected)
        skippcheck.setImage(bardone, for: UIControl.State.selected)
        newcheck.setImage(bardone, for: UIControl.State.selected)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func bar1858action(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveLinear, animations: {
            sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
            
        }) { (success) in
            UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveLinear, animations: {
                sender.isSelected = !sender.isSelected
                sender.transform = .identity
            }, completion: nil)
        }
    }
    
    @IBAction func circleaction(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveLinear, animations: {
            sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
            
        }) { (success) in
            UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveLinear, animations: {
                sender.isSelected = !sender.isSelected
                sender.transform = .identity
            }, completion: nil)
        }
    
    }
    
    }
    
    

